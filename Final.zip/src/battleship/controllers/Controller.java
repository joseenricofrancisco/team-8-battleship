package battleship.controllers;

/**
 * The parent class for other son classes in controllers package.
 * @author Peisong Yang
 *
 */
public class Controller {
	
	/**
	 * Default constructor
	 */
	public Controller() {
		
	}
}

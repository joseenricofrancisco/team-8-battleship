package battleship.controllers;
/**
 * This class is nor used for Demo3. It will be used in final submission.
 * @author Peisong Yang
 *
 */
public class Controller {

}

How to run this JUnit Test (in Eclipse):

1. Download the file "Demo3.zip" in https://github.com/joseenricofrancisco/team-8-battleship.
2. Download the file "ShipJUnit.zip" in the "Source" folder in https://github.com/joseenricofrancisco/team-8-battleship.
2. Unzip "Demo3.zip". Import the "src" folder as a project into Eclipse.
3. Unzip "ShipJUnit.zip". Import "ShipTest" into the "ship" package folder.
4. Right-click on the project, navigate to "Properties", then "Java Build Path".
5. Click "Add Library", then "JUnit", then choose "JUnit4" from the drop-down menu. Hit Finish.
6. Run "ShipTest" as a JUnit4 Test.